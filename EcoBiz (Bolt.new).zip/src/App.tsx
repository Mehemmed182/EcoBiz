import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Leaf, Building2, Factory, Search, BarChart, Rocket } from 'lucide-react';
import { CompanyProfile } from './components/CompanyProfile';
import { EcoDevices } from './components/EcoDevices';
import { EcoAnalysis } from './components/EcoAnalysis';
import { AIConsulting } from './components/AIConsulting';
import { SpaceView } from './components/SpaceView';

const EcoBizApp = () => {
  const [companyName, setCompanyName] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [activeTab, setActiveTab] = useState('profile');
  const [ecoScore, setEcoScore] = useState<number | null>(null);
  const [aiAdvice, setAiAdvice] = useState('');

  const analyzeEcoFriendliness = () => {
    const score = Math.floor(Math.random() * 100);
    setEcoScore(score);
    
    if (score < 30) {
      setAiAdvice("Your business has significant room for improvement in eco-friendliness. Consider implementing basic recycling programs, switching to energy-efficient lighting, and reducing water consumption as initial steps.");
    } else if (score < 70) {
      setAiAdvice("Your business is making progress in eco-friendliness, but there's still room for improvement. Look into renewable energy options, implement a comprehensive waste reduction strategy, and consider eco-friendly supply chain alternatives.");
    } else {
      setAiAdvice("Your business is doing well in terms of eco-friendliness! To further improve, consider achieving relevant environmental certifications, implementing a sustainability reporting system, and influencing your industry peers to adopt similar practices.");
    }
  };

  return (
    <div className="container mx-auto p-4 bg-background min-h-screen">
      <Card className="mb-4 border-green-500 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-green-600 to-green-400 text-white">
          <CardTitle className="flex items-center text-3xl font-bold">
            <Leaf className="mr-2 h-8 w-8" />
            EcoBiz - Green Solutions for SMEs
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-5 mb-8">
              <TabsTrigger value="profile" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                <Building2 className="mr-2 h-5 w-5" />
                Company Profile
              </TabsTrigger>
              <TabsTrigger value="eco-devices" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                <Factory className="mr-2 h-5 w-5" />
                Eco-Friendly Devices
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                <Search className="mr-2 h-5 w-5" />
                Eco Analysis
              </TabsTrigger>
              <TabsTrigger value="ai-consulting" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                <BarChart className="mr-2 h-5 w-5" />
                AI Consulting
              </TabsTrigger>
              <TabsTrigger value="space" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
                <Rocket className="mr-2 h-5 w-5" />
                Space View
              </TabsTrigger>
            </TabsList>
            <TabsContent value="profile">
              <CompanyProfile
                companyName={companyName}
                setCompanyName={setCompanyName}
                businessType={businessType}
                setBusinessType={setBusinessType}
              />
            </TabsContent>
            <TabsContent value="eco-devices">
              <EcoDevices />
            </TabsContent>
            <TabsContent value="analysis">
              <EcoAnalysis
                analyzeEcoFriendliness={analyzeEcoFriendliness}
                ecoScore={ecoScore}
              />
            </TabsContent>
            <TabsContent value="ai-consulting">
              <AIConsulting
                analyzeEcoFriendliness={analyzeEcoFriendliness}
                aiAdvice={aiAdvice}
              />
            </TabsContent>
            <TabsContent value="space">
              <SpaceView />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default EcoBizApp;