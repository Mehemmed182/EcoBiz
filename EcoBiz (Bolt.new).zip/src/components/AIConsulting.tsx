import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart, Lightbulb } from 'lucide-react';

interface AIConsultingProps {
  analyzeEcoFriendliness: () => void;
  aiAdvice: string;
}

export const AIConsulting: React.FC<AIConsultingProps> = ({ analyzeEcoFriendliness, aiAdvice }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <BarChart className="mr-2 h-6 w-6" />
          AI Consulting
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Button onClick={analyzeEcoFriendliness} className="mb-6 bg-blue-500 hover:bg-blue-600 w-full">
          <Lightbulb className="mr-2 h-5 w-5" />
          Get AI Advice
        </Button>
        {aiAdvice && (
          <div className="bg-blue-50 border-l-4 border-blue-500 p-6 mb-6 rounded-r-lg">
            <h3 className="text-xl font-semibold mb-3 text-blue-700 flex items-center">
              <Lightbulb className="mr-2 h-5 w-5" />
              AI Recommendations:
            </h3>
            <p className="text-sm text-gray-700 leading-relaxed">{aiAdvice}</p>
          </div>
        )}
        <div className="flex justify-center mt-6">
          <img src="https://source.unsplash.com/random/400x200?ai,consultant" alt="AI Consultant" className="rounded-lg shadow-md w-full max-w-md" />
        </div>
      </CardContent>
    </Card>
  );
};