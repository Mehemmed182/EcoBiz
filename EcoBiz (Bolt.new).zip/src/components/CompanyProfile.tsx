import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building2 } from 'lucide-react';

interface CompanyProfileProps {
  companyName: string;
  setCompanyName: (name: string) => void;
  businessType: string;
  setBusinessType: (type: string) => void;
}

const businessTypes = ['Manufacturing', 'Retail', 'Services', 'Technology', 'Agriculture'];

export const CompanyProfile: React.FC<CompanyProfileProps> = ({
  companyName,
  setCompanyName,
  businessType,
  setBusinessType
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Building2 className="mr-2 h-6 w-6" />
          Company Profile
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <label htmlFor="company-name" className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
            <Input
              id="company-name"
              type="text"
              placeholder="Enter your company name"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="w-full"
            />
          </div>
          <div>
            <label htmlFor="business-type" className="block text-sm font-medium text-gray-700 mb-1">Business Type</label>
            <Select onValueChange={setBusinessType} value={businessType}>
              <SelectTrigger id="business-type" className="w-full">
                <SelectValue placeholder="Select your business type" />
              </SelectTrigger>
              <SelectContent>
                {businessTypes.map((type) => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex justify-center">
            <img src="https://source.unsplash.com/random/400x200?eco,business" alt="Company logo placeholder" className="rounded-lg shadow-md w-full max-w-md" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};