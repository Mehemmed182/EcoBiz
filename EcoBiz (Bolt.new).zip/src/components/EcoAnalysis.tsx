import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Search, CheckCircle, AlertCircle } from 'lucide-react';

interface EcoAnalysisProps {
  analyzeEcoFriendliness: () => void;
  ecoScore: number | null;
}

export const EcoAnalysis: React.FC<EcoAnalysisProps> = ({ analyzeEcoFriendliness, ecoScore }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Search className="mr-2 h-6 w-6" />
          Eco-Friendliness Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Button onClick={analyzeEcoFriendliness} className="mb-6 bg-green-500 hover:bg-green-600 w-full">
          <Search className="mr-2 h-5 w-5" />
          Analyze Eco-Friendliness
        </Button>
        {ecoScore !== null && (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold mb-4">Your Eco-Friendliness Score:</h3>
            <div className="relative pt-1">
              <div className="flex mb-2 items-center justify-between">
                <div>
                  <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-green-600 bg-green-200">
                    Progress
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold inline-block text-green-600">
                    {ecoScore}%
                  </span>
                </div>
              </div>
              <Progress value={ecoScore} className="w-full h-2" />
            </div>
            <div className="bg-gray-100 rounded-lg p-4">
              <div className="flex items-center mb-2">
                {ecoScore < 30 ? (
                  <AlertCircle className="text-red-500 mr-2 h-5 w-5" />
                ) : ecoScore < 70 ? (
                  <AlertCircle className="text-yellow-500 mr-2 h-5 w-5" />
                ) : (
                  <CheckCircle className="text-green-500 mr-2 h-5 w-5" />
                )}
                <p className="text-lg font-semibold">
                  {ecoScore < 30 ? "Needs Improvement" :
                   ecoScore < 70 ? "Making Progress" :
                   "Excellent Performance"}
                </p>
              </div>
              <p className="text-sm text-gray-600">
                {ecoScore < 30 ? "Your business has significant room for improvement in eco-friendliness. Focus on implementing basic green practices." :
                 ecoScore < 70 ? "Your business is making progress, but there's still room for improvement. Consider more advanced eco-friendly strategies." :
                 "Your business is doing well in terms of eco-friendliness! Keep up the great work and aim for even higher standards."}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};