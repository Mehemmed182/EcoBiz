import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Factory } from 'lucide-react';

const ecoDevices = {
  'Energy': ['Solar Panels', 'LED Lighting', 'Smart Thermostats'],
  'Water': ['Low-flow Faucets', 'Dual-flush Toilets', 'Rainwater Harvesting Systems'],
  'Waste': ['Recycling Bins', 'Composting Systems', 'Waste Compactors']
};

const deviceDetails = {
  'Solar Panels': 'High-efficiency solar panels can significantly reduce your energy costs and carbon footprint.',
  'LED Lighting': 'LED lights use up to 75% less energy than incandescent bulbs and last much longer.',
  'Smart Thermostats': 'These devices can learn your schedule and preferences to heat and cool your home more efficiently.',
  'Low-flow Faucets': 'These faucets can reduce water flow by 30% or more without sacrificing performance.',
  'Dual-flush Toilets': 'These toilets allow you to choose between a full or partial flush, saving water.',
  'Rainwater Harvesting Systems': 'Collect and reuse rainwater for irrigation and other non-potable uses.',
  'Recycling Bins': 'Proper sorting bins encourage recycling and reduce waste sent to landfills.',
  'Composting Systems': 'Turn organic waste into nutrient-rich soil, reducing landfill waste.',
  'Waste Compactors': 'Reduce the volume of waste, leading to fewer waste collection trips.'
};

export const EcoDevices = () => {
  const [selectedDevice, setSelectedDevice] = useState('');

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Factory className="mr-2 h-6 w-6" />
          Find Eco-Friendly Devices
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Select onValueChange={setSelectedDevice}>
          <SelectTrigger>
            <SelectValue placeholder="Select a device category" />
          </SelectTrigger>
          <SelectContent>
            {Object.keys(ecoDevices).map((category) => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {selectedDevice && (
          <div className="mt-6 space-y-4">
            <h3 className="text-xl font-semibold mb-4">Recommended {selectedDevice} Devices:</h3>
            {ecoDevices[selectedDevice as keyof typeof ecoDevices].map((device) => (
              <Card key={device} className="bg-white shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="flex items-start p-4">
                  <div className="flex-shrink-0 mr-4">
                    <img src={`https://source.unsplash.com/random/100x100?${device.toLowerCase().replace(' ', ',')}`} alt={device} className="rounded-lg w-24 h-24 object-cover" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-lg mb-2">{device}</h4>
                    <p className="text-sm text-gray-600">{deviceDetails[device as keyof typeof deviceDetails]}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};