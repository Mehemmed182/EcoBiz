import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Rocket, Globe } from 'lucide-react';

export const SpaceView = () => {
  const [isLaunched, setIsLaunched] = useState(false);

  const handleLaunch = () => {
    setIsLaunched(true);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Rocket className="mr-2 h-6 w-6" />
          Space View
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center">
          <p className="mb-4 text-lg">Experience your eco-friendly business from a cosmic perspective!</p>
          {!isLaunched ? (
            <Button onClick={handleLaunch} className="bg-blue-500 hover:bg-blue-600">
              <Rocket className="mr-2 h-5 w-5" />
              Launch Space View
            </Button>
          ) : (
            <div className="space-y-4">
              <div className="relative w-full h-64 bg-black rounded-lg overflow-hidden">
                <div className="absolute inset-0 bg-blue-900 opacity-50 animate-pulse"></div>
                <Globe className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-blue-200 h-32 w-32" />
                <div className="absolute bottom-4 left-4 text-white text-sm bg-black bg-opacity-50 p-2 rounded">
                  Eco Impact: Positive
                </div>
              </div>
              <p className="text-sm text-gray-600">
                From this cosmic vantage point, we can see the positive impact your eco-friendly business is having on the planet. 
                Keep up the great work in reducing your carbon footprint and promoting sustainability!
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};