import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import EcoBizApp from './App';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <EcoBizApp />
  </StrictMode>
);